package com.example.batterytracker

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    private val permission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startTracking() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        else startTracking()
        setContent { MaterialTheme { Surface { HistoryScreen() } } }
    }

    private fun startTracking() =
        ContextCompat.startForegroundService(this, Intent(this, BatteryService::class.java))
}

@Composable
fun HistoryScreen() {
    val ctx = LocalContext.current
    val flow = remember { AppDb.get(ctx).dao().all() }
    val sessions by flow.collectAsState(initial = emptyList())

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Battery History", style = MaterialTheme.typography.headlineMedium) }
        if (sessions.isEmpty()) {
            item { Text("Tracking started. Plug in or unplug your phone to record a session.") }
        }
        items(sessions, key = { it.id }) { SessionCard(it) }
    }
}

@Composable
fun SessionCard(s: Session) {
    val dur = s.endTime - s.startTime
    val delta = s.endPct - s.startPct
    val hours = dur / 3_600_000.0
    val rate = if (hours > 0) abs(delta / hours) else 0.0
    val fmt = SimpleDateFormat("d MMM, h:mm a", Locale.getDefault())

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                if (s.charging) "⚡ Charging (${s.source})" else "🔋 On battery",
                fontWeight = FontWeight.Bold
            )
            if (s.open) Text("In progress", color = MaterialTheme.colorScheme.primary)
            Text("${fmt.format(Date(s.startTime))} → ${fmt.format(Date(s.endTime))}")
            Text("Duration: ${formatDuration(dur)}")
            Text("${s.startPct}% → ${s.endPct}% (${if (delta >= 0) "+" else ""}$delta%)")
            Text("Rate: ${"%.1f".format(rate)} %/hour")
            Text("Max temp: ${"%.1f".format(s.maxTempC)} °C")
        }
    }
}

fun formatDuration(ms: Long): String {
    val m = ms / 60_000
    return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"
}
